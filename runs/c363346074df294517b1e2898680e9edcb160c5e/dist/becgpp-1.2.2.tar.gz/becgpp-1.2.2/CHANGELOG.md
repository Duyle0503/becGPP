# 1.2.2 (2026-10-18)

Release described in the Computer Physics Communications article. The discrete
energy functional, kernels and diagnostics are those of 1.2.2rc1; the solver
differs only in the recentring of translation-invariant states (below).

- `default_cfg` warns (`RuntimeWarning`) when rotation leaves the energy
  unbounded below: `Omega != 0` with `s < 2`, or `s = 2` with
  `Omega**2 > 2*trap_coeff` (`tests/test_regime_warning.py`).
- Translation-invariant problems (no trap, no rotation, no long-range term):
  the converged state is shifted by whole grid cells so that its periodic
  centre of mass sits at the box centre (`recentred_shift` in the output).
  This is an exact symmetry of the discrete energy; it removes drift along the
  translation mode that could carry a free droplet across the periodic
  boundary and spoil radii and figures (`tests/test_recentre.py`). Found by
  the CPU reference run. Trapped and long-range runs are unaffected.
- `examples/cpu_test_run.py`: a reference test run on a CPU (a few minutes) that
  exercises the validation gate and seven small configurations covering every
  kernel, 2D/3D/quasi-2D, rotation and the cubic-quintic terms; `--check`
  compares with the shipped reference.
- `data/sample_output/` regenerated with this version from that test run
  (CSV, per-run JSON, figures and `expected_results.json`); the version-1.0
  scan files were removed (they remain in the git history).
- README: install from the archive or the release tag, regime of validity,
  complete package layout.

# 1.2.2rc1 — release candidate (2026-10-15)

CUDA review follow-up (2026-10-17): make random-state and direct-quadrature
test fixtures device-aware so the full 97-test suite can be selected on CUDA.
Numerical solver modules are unchanged. The supplied CUDA run exposed fixture
errors. A separate Tesla T4 rerun at commit 75f0a30 subsequently passed all 97
tests in 29.52 seconds, with no errors, skips or excluded cases (reviewed
2026-10-18). The original physics batch and review flags are retained.

CPC tooling follow-up (2026-10-18): publish the one-cell GPU runners and bundle
audit/packaging helpers under tools/cpc, with workspace discovery for the separate
code/data/latex bundle. Numerical modules and test assertions are unchanged.

- Recover failed conjugate-gradient searches with a fresh descent direction and
  complete backtracking; clear stale BB/CG history. Stalls are not labelled as
  proof of rounding. Enforce complex128 and validate initial states.
- Resample continuation in physical coordinates even when array shapes match.
- Exclude radii outside rmax from radial bins.
- Use coexistence for trapped cubic–quintic TF, reporting finite-grid mass error.
- Deep-copy configuration lists; validate keys, finite values and integer counts
  at public entry points; explicitly construct float64 grids.
- Stabilize the thin-disc virial kernel with a large-argument expansion.
- Append single-run CSV records, write sweep JSON provenance and sum multi-seed time.
- Include examples, benchmarks and documentation in source distributions; pin
  historical benchmark commits and correct regenerated LLL parameters.
- Add independent direct-convolution, nonlinear, provenance and numerical regressions.
- Warn (`RuntimeWarning`) when rotation leaves the energy unbounded below:
  `Omega != 0` with `s < 2`, or `s = 2` with `Omega**2 > 2*trap_coeff`
  (`tests/test_regime_warning.py`). Numerical modules are unchanged.

Historical production CSVs retain their original version labels and values.

# Changelog

## 1.2.1 (2026-10-03)

Bug-fix release from a code audit. Converged ground states of 1.2.0 are
unchanged; see `tests/test_audit.py` for a regression test per item.

### Fixed
- **Solver ran to `maxit` once the energy had settled.** After a failed Armijo
  search the Barzilai-Borwein mix pulled the trial step back to ~2/3 of the
  unchanged BB step, so `alpha_min` (the only stall exit) was unreachable, and
  the energy-window stop is evaluated on accepted steps only. When the residual
  floor of the grid lay above `res_tol`, the solver repeated identical line
  searches (8 energy evaluations each) until `maxit` -- e.g. 242 s instead of
  0.24 s for the non-interacting 2D trap at `res_tol=1e-9`. It now stops with
  `stop_reason="line_search_stalled"` after `linesearch_stall` (new key,
  default 10) consecutive failures. Runs without such a stall are bit-identical.
- `obs["iters"]` is the number of iterations performed (it was the last
  0-based loop index, one less; `maxit` runs now report `maxit`).
- **Checkpoint collisions.** The run id hashed only 17 keys, so runs differing
  in e.g. `seed_winding`, `seed_noise`, `energy_tol` or the line-search settings
  resumed each other's checkpoints. It now hashes every key that can change the
  state (all but output/diagnostic/mode settings and `maxit`). Run ids differ
  from 1.2.0, so old checkpoints are not resumed.
- **Config files bypassed validation.** Keys from `--config` were merged with
  `dict.update`: aliases (`res:`) were ignored, typos (`omega:`) accepted
  silently, and YAML numbers such as `1e3` (strings for PyYAML) crashed later
  with a `TypeError`. Files now go through `default_cfg` and are typed like the
  CLI flags.
- `sweep_param` is validated (unknown or non-numeric keys raise, aliases map);
  an empty `sweep_values` returns `[]` instead of crashing.
- `mode_smoke` reported `OVERALL=True` whether or not the run converged.
- **Negative rotation.** The triangular seed imprinted `+1` vortices for
  `Omega<0`; `w_LLL` projected on `z^m` instead of `conj(z)^m`; the vortex
  smoothing length and the lattice coarse-graining in the TF figure used the
  signed `Omega`; `E_bind` was defined only for `Omega=+1`.
- `resample_state` assumed the grid starts at `-L`, which holds for even
  `Ngrid` only; odd grids were shifted by `dx/2` (error ~0.1 on the identity map).
- `dimension` values other than `2D`, `3D`, `quasi2D` (e.g. `"1D"`) silently
  ran in 2D; they now raise.
- `auto_grid` returned a negative radius estimate for `G_C<0`.
- The Thomas-Fermi reference of the trapped pure quintic gas (`beta2=0`,
  `beta3>0`) was missing; it is `sqrt((mu-V)/beta3)`.
- `mode_convergence` took the last grid in `conv_Ngrids` as the finest one;
  it now uses the largest `N`.
- **The `becgpp` command exited with status 1 after a successful run** (and
  printed the result dict to stderr): the console script does `sys.exit(main())`
  and `main` returns the result. The entry point is now `becgpp.cli:console`,
  which returns 0; `main` still returns the result for use from Python.
- `examples/kaggle_demo.py` installed the non-existent tag `v1.1.1`.

- The triangular seed at `Omega=0` (only when requested explicitly) imprinted
  `-1` vortices; it now uses `+1`, as for `Omega>0`.

### Changed
- **Benchmark layout.** The paper scripts are named by what they compute and
  their raw outputs live in `benchmarks/results/<script>/`:
  `kaggle_v11_step2_confirm.py` -> `verification.py`,
  `kaggle_v11_step3_references.py` -> `selfgravity_limits.py`,
  `kaggle_v11_step4_itp_compare.py` -> `itp_agreement.py`,
  `kaggle_v12_ma4_timing.py` -> `itp_timing.py`;
  `results_v1.1/step{2,3,4}`, `results_v1.2` -> `results/{verification,
  selfgravity_limits,itp_agreement,itp_timing}`. `make_paper_numbers.py` reads
  that layout and also draws the time-to-accuracy figure; `benchmarks/README.md`
  maps every script to the tables and figures it produces. The unused
  `_kaggle_common.py` was removed. Script behaviour is unchanged.
- README: stop reasons and the double-precision residual floor (~1e-8) explained.

### Added
- `tests/test_audit.py`: energy gradient vs `H` by finite differences for every
  kernel and dimension, kernel symmetry, `mu = <H>`, exact non-interacting
  energies, vortex counting, LLL weight, CLI typing, and the regressions above.

## 1.2.0 (2026-09-26)

### Changed
- **Default `cg_beta` is now `"pr_precond"`** (Polak-Ribiere coefficient in the
  Sobolev metric of the preconditioner, `beta = <z, g-g_old>/<z_old, g_old>`).
  On the 2D rotating benchmark it reaches `res_tol=1e-8` in about 250 iterations
  with about 1.7 energy evaluations per iteration, where `"pr"` needs about 7.9
  line-search trials per iteration and stalls near 1e-7. Set `cg_beta="pr"` to
  reproduce 1.0-1.1 (the v1.1 benchmark scripts pin it).
- The long-range potential `Phi` computed for the accepted line-search trial is
  reused by the residual and the preconditioner: 1.7 instead of 3.7 zero-padded
  convolutions per iteration with `"pr_precond"`; iterates are bit-identical.

### Added
- `record_trace=True` keeps `(wall time, iteration, E, residual)` per iteration
  in `obs["trace"]` (device-synchronized timings).
- `benchmarks/kaggle_v12_ma4_timing.py` (now `benchmarks/itp_timing.py`): time-to-accuracy of PCG (`pr_precond`,
  `pr`) against imaginary-time split-step at several time steps, on four cases.

## 1.1.1 (2026-09-26)

### Fixed
- `lll_param` used the intra-LLL spacing `2(1-Omega)` as the gap. The gap to the
  next Landau level in the rotating frame is `(1+Omega)` (2 hbar*omega at Omega=1),
  so `lll_param = beta2*n_peak/(1+Omega)`; it is now also reported at `Omega = 1`.

## 1.1.0 (2026-09-24)

### Fixed
- **Virial identity for the `-ln r` kernel.** The long-range term is `-G_C/2`
  (unit mass), not `p*E_g` with `p=0`; the old formula reported a virial residual
  of order 0.5 for correct `-ln r` ground states.
- **Unit conversion of the gravitational coupling.** `G_C = G m^2 N /(a_ho hbar w)`
  (one factor of N, per-particle energy, like `beta2 = g N`); 1.0.0 used `N^2`.
- **Sweeps at fast rotation** could stay on a vortex-free (metastable) branch,
  because each point was warm-started from the previous one only. A sweep point
  now tries continuation *and* `nseeds` fresh seeds and keeps the lowest energy
  (`branch`, `candidate_E` columns). Multi-seed selection is now variational
  (lowest energy wins); 1.0.0 preferred any converged candidate over a lower-energy
  one that had not yet reached `res_tol`.
- Exact self-cell average for the `-ln r` kernel (was a Gauss-Legendre estimate).
- Cache keys: `trap_coeff`, `l_z`, `nseeds`, `cg_beta` now enter the run id and the
  Thomas-Fermi cache (a changed `trap_coeff` could reuse a stale TF/checkpoint).
- Config keys `step`, `step_max`, `linesearch_max`, `precond_shift(_min)` are now
  actually used by the solver (defaults reproduce 1.0.0 exactly).

### Changed
- **Safe defaults**: `Omega=0`, `G_C=0`, `L=10`, `Ngrid=128` (1.0.0 defaulted to
  critical rotation with a long-range term on a 256-point grid).
- `w_LLL` is reported only for rotating 2D runs in the harmonic trap; new
  `lll_param` (see 1.1.1 for the corrected definition).
- Validation gate: adds `-ln r` and quasi-2D Gaussian tests and the `-ln r` kernel
  order; 3D threshold tightened from 5e-2 to 5e-3.
- Triangular seeds are used only for rotating runs (`|Omega| >= 0.3`).
- Estimated peak memory is printed as a warning before oversized grids.
- Lists can be passed on the command line as JSON (`--sweep_values "[5,10]"`).
- `zip_output` defaults to False.

### Added
- **Quasi-2D kernel `q2d`**: the Newton kernel averaged over a frozen Gaussian
  axial profile of width `l_z`, `K_eff(u) = e^x K0(x)/(sqrt(2 pi) l_z)`,
  `x = u^2/4 l_z^2`; `dimension="quasi2D"` selects it when `l_z > 0` (thin-disc
  `1/r` when `l_z = 0`). Unit mapping `regime="selfgrav_pancake"`.
- `cg_beta` option: `pr` (default, as 1.0.0), `pr_precond`, `none`.
- Diagnostics: `stop_reason`, `seed_used`, `points_per_R90`, `virial_lr_term`.
- `benchmarks/`: Kaggle scripts that regenerate the paper's tables and figures, and
  `benchmarks/results_v1.1/`: the raw results (Tesla T4) quoted in the paper.
- Tests for kernel virials, kernel limits, safe defaults and unit scaling.
